

/***************************** Include Files *******************************/
#include "SOC_NeoPixel_AXI_Core.h"

/************************** Function Definitions ***************************/
