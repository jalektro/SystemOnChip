-= SD card boot image =-

Platform: SOC_NeoPixel_AXI
Application: SOC_NeoPixel_Axi

1. Copy the contents of this directory to an SD card
2. Set boot mode to SD
3. Insert SD card and turn board on
